;****************** main.s ***************
; Program written by: 
; Date Created: 
; Last Modified: 
; Brief description of the program:
;	
  

 ; ********************************************************************
 ; ********************* EQU Label Definitions ************************
 ; ********************************************************************

; Port F Data registers
GPIO_PORTF_DATA_R  	EQU 0x400253FC	; to read all bits on Port F
GPIO_PORTF_DATA_SWS	EQU	0x40025044	; to read both switches on Port F, bits 0 & 4
GPIO_PORTF_DATA_LED	EQU	0x40025038	; Port F data bits 1-3
	
; SysTick Timer addresses
NVIC_ST_CTRL_R 		EQU 0xE000E010	; SysTick Control and Status Register (STCTRL)
NVIC_ST_RELOAD_R	EQU 0xE000E014	; SysTick Reload Value register (STRELOAD)
NVIC_ST_CURRENT_R	EQU 0xE000E018	; SysTick Current Value Register (STCURRENT)
	
; LED Colors
RED		EQU	2_00010
BLUE	EQU 2_00100
GREEN	EQU	2_01000
ALLOFF	EQU	2_00000
ALLON	EQU	2_01110
	
; Period of LED
;PRD_RED		EQU	25
;PRD_BLUE	EQU 50
;PRD_GREEN	EQU 75


	THUMB
		
; *********************************************************************
; ************************* ROM CONSTANTS AREA ************************
; *********************************************************************
; Constants and code area starts at address 0x0000.0000
	AREA    MyConstants, DATA, READONLY, ALIGN=2		; Flash EEPROM

		 
	ALIGN
		 
		 
; *********************************************************************
; ************************* RAM VARIABLES AREA ************************
; *********************************************************************
; SRAM variables area starts at address 0x2000.0000
	AREA    MyVariables, DATA, READWRITE, ALIGN=2		; SRAM

	ALIGN		  
		  
		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		    
	ALIGN
		  
	EXPORT  Start
		  
Start


Prog_Init

; Configure Port F
	IMPORT	PortF_Config
	BL		PortF_Config
	NOP
; Configure SysTick Timer
	IMPORT	SysTick_Config
	BL		SysTick_Config
	NOP
	
	
; ******************************************************************
; ********************** MAIN PROGRAM ******************************
; ******************************************************************
;	f = 16MHz	-->	T = 62.5 ns
	
; Main function starts here
; Initialization the finite-state machine

	
loop
	; check sws event
	; set the state, LED etc
	; use the timer, and check the timer event 

	
	B	loop
	NOP	



;******************************************************************
;************************ SUBROUTINES *****************************
;******************************************************************

; Put your subrouites from here, if you need.
	

;; #######################################################################
;; You can use the following subroutines of timers, or develop your own.
;; 2 subroutines have been provided.
;; MyTime will wait #imme times of 10 ms and return
;; SysTick_wait will wait #imme clock cycles and return
;; ######################################################################

; ******************** MyTimer ********************	
; Time delay using busy wait. This assumes 16MHz clock
; Input: R0 --> # of times to wait 10 ms before returning
; Output: none
; Modifies: R0, R4
; Function Calls: YES, need to push LR before call other functions.

DELAY10MS EQU	160000			; 160,000 ticks of 16MHz clock = 10ms = 0.01 S
	                            ; If R0 = N, then the total count down time will be 0.01*N Seconds
	
MyTimer
	PUSH {R4, LR}				; save current value of R4 and LR
	MOVS R4, R0					; R4 = R0 = remainingWaits
	BEQ MyTimer_done	; R4 == 0, done
MyTimer_loop
	LDR R0, =DELAY10MS			; R0 = DELAY10MS
	BL SysTick_Wait				; expects R0 to hold # of ticks to time
	SUBS R4, R4, #1				; R4 = R4 -1; remaining10msWaits--
	BHI MyTimer_loop	; if (R4 > 0), wait another 10ms
MyTimer_done			
	POP {R4, LR}
	BX	LR



; *********************SysTick Wait **************************
; Time delay using busy wait.
; Input: R0 --> # of the cycles to wait before returning
; Output: none
; Function Calls: No
SysTick_Wait
	; load counter with desired number of ticks
	LDR	R1,	=NVIC_ST_RELOAD_R	; R1 = &NVIC_ST_RELOAD_R
	
	; counter ticks N + 1 times so need to subtract 1
	SUB	R0,	#1					
	STR	R0,	[R1]
	
	; reset count bit
	LDR	R1, =NVIC_ST_CURRENT_R
	STR	R1, [R1]
	
	; get address of register that has COUNT bit
	LDR	R1,	=NVIC_ST_CTRL_R		; R1 = & NVIC_ST_CTRL_R

SysTick_Wait_loop
	LDR	R3,	[R1]
	ANDS R3, R3, #0x00010000	; COUNT bit is bit 16
	BEQ	SysTick_Wait_loop		; if COUNT == 0, the counter has not hit zero, so keep waiting
	BX	LR


;*********************** END SUBROUTINES **************************
      
    ALIGN      ; make sure the end of this section is aligned
    END        ; end of file

