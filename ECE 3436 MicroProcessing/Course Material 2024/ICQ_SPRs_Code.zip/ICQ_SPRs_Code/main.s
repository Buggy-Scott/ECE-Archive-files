;****************** main.s ***************
; Author: Diana de la Rosa-Pohl
; Date Created: 3/31/20 
; Last Modified: 11/14/2022 

; ********************* WARNING!!! **************************
; This program has errors! The AAPCS is not followed.
; Fix the program to make sure that it is AAPCS compliant.
; ********************* WARNING!!! **************************
;

      THUMB		; use Thumb instruction set
		  
;********** SET UP ROM AREA (Constants) *******************
;**********************************************************
	AREA	myConstants, DATA, READONLY, ALIGN=2
	; This data is placed in ROM after the code section

		

		
		
;*************** SET UP RAM AREA (Variables) *******************
;***************************************************************
	AREA    myVariables, DATA, READWRITE, ALIGN=2
	; SRAM addresses start at 0x2000.0000





;****************** SET UP CODE AREA ******************
;******************************************************
    AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash EEPROM
	; ROM addresses begin at 0x0000.0000
	; this code starts at 0x0000.0284
		  
    EXPORT  Start


Start


loop

	MOV	R0, #0
	MOV	R1,	#1
	MOV	R2,	#2
	MOV	R3, #3
	MOV	R4, #4
	MOV	R5,	#5
	MOV	R6,	#6
	
	PUSH {R5, R6}
	MOV32	R5, #0x55555555
	MOV32	R6, #0x66666666

	
	BL	GetSum	; Does this subroutine alter R0-R3?
	NOP


	BL	GetMinMax
	NOP


	BL	GetMean
	NOP


	BL	GetSquares
	NOP

	POP {R5, R6}

	B	loop
	


; ********************************************************************************************
; ************************************** SUBROUTINES *****************************************
; BEWARE: subroutines are allowed to modify R0-R3, R12
; Subroutine Protocol
;	R0 - R3 are used to pass parameters to submroutines. The subroutine can alter those values all it wants.
;	The subroutine IS allowed to use R4-R11. However, it must restore the values before returning.
;	If you only return one value from the subroutine, return it in R0. (Then use R1, then R2,...)


; ********************************************
; GetSum
;	inputs --> R0-R4
;	return value --> R0
GetSum
	ADD R0, R0, R1
	ADD	R0,	R2
	ADD	R0, R3
	ADD	R0, R4
	
	BX	LR		; result is returned in R0


; *********************************************
; GetMinMax
;	inputs --> R0-R4
;	return values --> R0 (min), R1 (max)
GetMinMax

	; Get minimum
	MOV	R5, R0	; R5 has current min
	CMP	R1, R5
	MOVLT R5, R1
	CMP	R2,	R5
	MOVLT R5, R2
	CMP	R3, R5
	MOVLT R5, R3
	CMP	R4, R5
	MOVLT R5, R4
	
	; Get maximum
	MOV	R6, R0	; R6 has current max
	CMP	R1, R6
	MOVGT R6, R1
	CMP	R2,	R6
	MOVGT R6, R2
	CMP	R3, R6
	MOVGT R6, R3
	CMP	R4, R6
	MOVGT R6, R4	
	
	MOV	R0, R5
	MOV	R1, R6
	
	BX	LR		; results are returned in R0 & R1


; *********************************************
; GetMean
;	inputs --> R0-R4
;	return value --> R0 
GetMean	
	PUSH {R4, LR}
	BL	GetSum	; sum is returned in R0
	POP {R4, LR}
	MOV	R5, #5
	UDIV R0, R0, R5

	BX	LR		; result is returned in R0


; *********************************************
; GetSumOfSquares
;	inputs --> R0-R4
;	return value --> R0 
GetSquares	

	MUL	R0, R0, R0
	MUL	R1, R1, R1
	MUL	R2, R2, R2
	MUL	R3, R3, R3
	MUL	R4, R4, R4
	
;	BL	GetSum
	NOP
	
	BX	LR



ALIGN        ; make sure the end of this section is aligned
	END          ; end of file
		  



          