;****************** main.s ***************
; Program written by: Dr. D
; Date Created: 09/25/023
; Last Modified: 09/23/2023
; Brief description of the program: ASCII character counter

	THUMB
		
; Test Pattern 1
Pattern1		EQU		2_00110000001100010011001000110011		; 0,1,2,3
;Pattern1		EQU		2_01000001010000100100001101000100		; A,B,C,D
;Pattern1		EQU		2_00000000000000000000000000000000		; NULL, NULL, NULL, NULL
;Pattern1		EQU		2_01001111010010000000000000110110		; O,H,NULL,6

		  
; *********************************************************************
; *************************** CODE AREA IN ROM ************************
; *********************************************************************
	AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash ROM
		  		  		 
	EXPORT  Start

; ********************* MAIN PROGRAM ****************************

Start





      
      ALIGN        ; make sure the end of this section is aligned
      END          ; end of file