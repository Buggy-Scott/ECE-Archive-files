;****************** main.s ***************
; Author: Diana de la Rosa-Pohl
; Author: Jianfeng Zheng
; Date Created: 3/31/20 
; Last Modified: 03/27/2024 


      THUMB		; use Thumb instruction set
		  
;********** SET UP ROM AREA (Constants) *******************
;**********************************************************
	AREA	myConstants, DATA, READONLY, ALIGN=2
	; This data is placed in ROM after the code section

		
		
;*************** SET UP RAM AREA (Variables) *******************
;***************************************************************
	AREA    myVariables, DATA, READWRITE, ALIGN=2
	; SRAM addresses start at 0x2000.0000
	
VarX	SPACE	4
VarY	SPACE	4
VarZ	SPACE	4

;****************** SET UP CODE AREA ******************
;******************************************************
    AREA    |.text|, CODE, READONLY, ALIGN=2		; Flash EEPROM
	; ROM addresses begin at 0x0000.0000
	; this code starts at 0x0000.0284
		  
    EXPORT  Start


Start

;;;; ICQ #7
	LDR	R1, =VarX
	MOV	R0, #0x1111
	STR R0, [R1]
	LDR R1, =VarY
	MOV R0, #0x2222
	STR R0, [R1]
	
	LDR R2, =VarX
	LDR R0, [R2]
	LDR R3, =VarY
	LDR R1, [R3]
	PUSH {R0,R1}
	BL	addemup
	POP {R0,R1}

	B	endf

;;;; Subroutines
addemup
	ADD	R0, R0, R1
	LDR R1, =VarZ
	STR R0, [R1]
	
;	LDR R1, =0x2000040C
;	STR R0, [R1]
	
	BX	LR

endf
	NOP
	NOP

	ALIGN        ; make sure the end of this section is aligned
	END          ; end of file
          